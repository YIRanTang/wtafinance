from distutils.core import setup

setup(
    name='wtafinance',
    version='0.3',
    description='This is wtafinance of the setup',
    author='tby',
    author_email='1049268431@qq.com',
    url='',
    packages=['wtafinance','wtafinance.finance_api','wtafinance.tools','wtafinance.wta']
)