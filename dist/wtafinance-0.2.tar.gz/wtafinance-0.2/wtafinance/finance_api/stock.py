from  wtafinance.tools import mongodb_helper

class DataApi(object):
    _instance = None
    def __init__(self):
        self.db = mongodb_helper.Mongo()

    # 单例
    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            return cls._instance
        else:
            return cls._instance



    def wta_getBalanceSheet(self,code:str=None,start_time:str=None,end_time:str=None)->list:
        '''
        非金融资产负债表
        :param code: 股票代码
        :param start_time:报告开始时间
        :param end_time:报告结束时间
        :return: list
        '''
        filter = {}
        filter["$and"] = []
        if code != None:
            filter["SECCODE"] = code
        if start_time != None:
            filter["$and"].append({"F001D": {"$gte": start_time}})
        if end_time != None:
            filter["$and"].append({"F001D": {"$lte": end_time}})
        if filter["$and"]==[]:
            del filter["$and"]
        data = self.db.find("非金融资产负债表", filter)
        for i in data:
            del i["_id"]
        data.sort(key=lambda x:x["F001D"])
        return data

    def wta_getCashStatement(self,code:str=None,start_time:str=None,end_time:str=None)->list:
        '''
        非金融现金表
        :param code: 股票代码
        :param start_time:报告开始时间
        :param end_time:报告结束时间
        :return: list
        '''
        filter = {}
        filter["$and"] = []
        if code != None:
            filter["SECCODE"] = code
        if start_time != None:
            filter["$and"].append({"F001D": {"$gte": start_time}})
        if end_time != None:
            filter["$and"].append({"F001D": {"$lte": end_time}})
        if filter["$and"]==[]:
            del filter["$and"]
        data = self.db.find("非金融现金表", filter)
        for i in data:
            del i["_id"]
        data.sort(key=lambda x:x["F001D"])
        return data

    def wta_getIncomeStatement(self,code:str=None,start_time:str=None,end_time:str=None)->list:
        '''
        非金融利润表
        :param code: 股票代码
        :param start_time:报告开始时间
        :param end_time:报告结束时间
        :return: list
        '''
        filter = {}
        filter["$and"] = []
        if code != None:
            filter["SECCODE"] = code
        if start_time != None:
            filter["$and"].append({"F001D": {"$gte": start_time}})
        if end_time != None:
            filter["$and"].append({"F001D": {"$lte": end_time}})
        if filter["$and"]==[]:
            del filter["$and"]
        data = self.db.find("非金融利润表", filter)
        for i in data:
            del i["_id"]
        data.sort(key=lambda x:x["F001D"])
        return data

    def wta_getPerfReport(self,code:str=None,start_time:str=None,end_time:str=None)->list:
        '''
        业绩报告
        :param code: 股票代码
        :param start_time:报告开始时间
        :param end_time:报告结束时间
        :return:list
        '''
        filter = {}
        filter["$and"] = []
        if code!=None:
            filter["SECCODE"] = code
        if start_time != None:
            filter["$and"].append({"F001D":{"$gte":start_time}})
        if end_time != None:
            filter["$and"].append({"F001D":{"$lte":end_time}})
        if filter["$and"]==[]:
            del filter["$and"]
        data = self.db.find("业绩报告",filter)
        for i in data:
            del i["_id"]
        data.sort(key=lambda x: x["F001D"])
        return data

