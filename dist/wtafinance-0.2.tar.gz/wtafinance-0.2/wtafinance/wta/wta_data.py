from wtafinance.finance_api import stock

def wta_api():
    return stock.DataApi()