from wtafinance.finance_api import stock
from wtafinance.tools import mongodb_helper

def wta_api():
    return stock.DataApi()